#!/usr/bin/env python3
"""
女频小说评分工具
用法：python3 scoring_tool.py --file <小说文件> --type [short|long]
"""

import argparse
import json
import sys

def calculate_score(novel_data, novel_type):
    """
    根据评分系统计算总分
    novel_data: dict，包含各维度得分
    novel_type: 'short' 或 'long'
    """
    
    # 基础评分标准（总分100）
    scores = {
        "character": novel_data.get("character", 0),  # 人设吸引力 25分
        "emotion": novel_data.get("emotion", 0),      # 情感张力 20分
        "plot": novel_data.get("plot", 0),            # 剧情结构 20分
        "innovation": novel_data.get("innovation", 0), # 创新度 15分
        "writing": novel_data.get("writing", 0),       # 文笔与阅读体验 10分
        "market": novel_data.get("market", 0)          # 市场适配度 10分
    }
    
    total = sum(scores.values())
    
    # 确定等级
    if total >= 90:
        grade = "S级（爆款潜质）"
        can_publish = True
    elif total >= 80:
        grade = "A级（优质作品）"
        can_publish = True
    elif total >= 70:
        grade = "B级（及格作品）"
        can_publish = False
    elif total >= 60:
        grade = "C级（待改进）"
        can_publish = False
    else:
        grade = "D级（不推荐）"
        can_publish = False
    
    # 找出短板
    weaknesses = []
    if scores["character"] < 23:
        weaknesses.append("人设吸引力不足")
    if scores["emotion"] < 18:
        weaknesses.append("情感张力不够")
    if scores["plot"] < 18:
        weaknesses.append("剧情结构有问题")
    if scores["innovation"] < 13:
        weaknesses.append("创新度不高")
    if scores["writing"] < 9:
        weaknesses.append("文笔readability待提升")
    if scores["market"] < 9:
        weaknesses.append("市场适配度不够")
    
    return {
        "total_score": total,
        "grade": grade,
        "can_publish": can_publish,
        "scores": scores,
        "weaknesses": weaknesses,
        "suggestions": generate_suggestions(scores, novel_type)
    }

def generate_suggestions(scores, novel_type):
    """根据扣分情况生成修改建议"""
    suggestions = []
    
    if scores["character"] < 20:
        suggestions.append("💡 人设问题：男主需要更多脆弱面和秘密；女主需要脱离模板化")
    
    if scores["emotion"] < 16:
        suggestions.append("💡 情感问题：增加推拉感；设计强制性亲密场景；虐甜比例调整")
    
    if scores["plot"] < 16:
        if novel_type == "short":
            suggestions.append("💡 剧情问题（短篇）：开篇3章需要强冲突；加快节奏")
        else:
            suggestions.append("💡 剧情问题（长篇）：检查中期是否崩盘；伏笔是否回收")
    
    if scores["innovation"] < 12:
        suggestions.append("💡 创新问题：对标3本同类型爆款，找出可反转的点")
    
    if scores["writing"] < 8:
        suggestions.append("💡 文笔问题：每章结尾加钩子；增加戳心台词")
    
    if scores["market"] < 8:
        suggestions.append("💡 市场问题：研究目标平台调性；增加热门标签元素")
    
    return suggestions

def interactive_scoring(novel_type):
    """交互式评分"""
    print(f"\n{'='*60}")
    print(f"  女频{'短篇' if novel_type == 'short' else '长篇'}小说评分系统")
    print(f"{'='*60}\n")
    
    print("请按提示输入各维度得分（参考 scoring_system.md）\n")
    
    scores = {}
    dimensions = [
        ("character", "人设吸引力", 25),
        ("emotion", "情感张力", 20),
        ("plot", "剧情结构", 20),
        ("innovation", "创新度", 15),
        ("writing", "文笔与阅读体验", 10),
        ("market", "市场适配度", 10)
    ]
    
    for key, name, max_score in dimensions:
        while True:
            try:
                score = float(input(f"{name}（满分{max_score}）："))
                if 0 <= score <= max_score:
                    scores[key] = score
                    break
                else:
                    print(f"  ❌ 请输入0-{max_score}之间的数字")
            except ValueError:
                print("  ❌ 请输入数字")
    
    result = calculate_score(scores, novel_type)
    
    print(f"\n{'='*60}")
    print(f"  评分结果")
    print(f"{'='*60}")
    print(f"\n总分：{result['total_score']}/100")
    print(f"等级：{result['grade']}")
    print(f"可否签约：{'✅ 可以' if result['can_publish'] else '❌ 需要修改'}")
    
    print(f"\n各维度得分：")
    for key, name, max_score in dimensions:
        score = scores[key]
        bar = "█" * int(score / max_score * 20)
        print(f"  {name}：{score}/{max_score} {bar}")
    
    if result['weaknesses']:
        print(f"\n⚠️  短板：")
        for w in result['weaknesses']:
            print(f"  - {w}")
    
    if result['suggestions']:
        print(f"\n💡 修改建议：")
        for s in result['suggestions']:
            print(f"  {s}")
    
    print(f"\n{'='*60}")
    
    return result

def main():
    parser = argparse.ArgumentParser(description="女频小说评分工具")
    parser.add_argument("--file", help="小说评分数据JSON文件")
    parser.add_argument("--type", choices=["short", "long"], default="short", 
                        help="小说类型：short（短篇2-3万字）或 long（长篇100万字+）")
    parser.add_argument("--interactive", "-i", action="store_true", 
                        help="交互式评分")
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_scoring(args.type)
    elif args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            novel_data = json.load(f)
        result = calculate_score(novel_data, args.type)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("请使用 --interactive 进行交互式评分，或 --file 指定评分数据文件")
        print("\n示例：")
        print("  python3 scoring_tool.py --interactive --type short")
        print("  python3 scoring_tool.py --file score.json --type long")

if __name__ == "__main__":
    main()
